# Handoff: Singh Beans Coffee — Homepage + Café Landing Page

## Overview
Website redesign for Singh Beans Coffee, a family-owned small-batch roaster in Surrey/Vancouver, BC, launching its first café. Two pages: **Homepage** and **Café landing page**. Mobile-first; most café traffic is on phones.

Audience priority: (1) locals looking for the café, (2) online bean buyers, (3) event/wedding clients booking the mobile coffee cart, (4) wholesale accounts.

Current live site is Squarespace (singhbeans.com). The existing shop, cart, event-booking and wholesale pages are out of scope; link to them.

## About the Design Files
`Homepage.dc.html` and `Cafe.dc.html` are **design references built in HTML**. They're prototypes that show the intended look and behaviour, not production code. Rebuild them in the target stack. If no codebase exists yet, a static-first framework such as Astro, Next.js (static export) or Eleventy fits: a content site with strong local-SEO needs. The alternative is a custom Squarespace/Shopify theme if the client stays on a hosted platform.

The files use a proprietary streaming template format: `{{ }}` holes, `<sc-if>`, and a `class Component extends DCLogic` logic block. Read them for markup, inline styles and copy. Ignore the runtime (`support.js`), which is included only so the files open in a browser. Every style is inline, so move them into your CSS system and tokens (listed below).

## Fidelity
**High-fidelity.** Colours, type, spacing, radii, borders and copy are final unless marked **TBC**. Recreate them faithfully.

## Aesthetic
"Hand-applied sticker on a lamppost": bold, flat, friendly, warm, a little irreverent.

- Thick espresso outlines (2.5–3px), fully rounded pill buttons, and flat offset shadows (no blur).
- A few elements are slightly rotated, like stickers.
- **No gradients, no black, no stacked promo banners, no raw URLs as text.**
- Use the logo as supplied. Never redraw it.

## Design Tokens

### Colours
| Token | Hex | Use |
|---|---|---|
| espresso | `#3A2218` | Anchor: text, borders, dark sections, footer |
| cream | `#F5ECDC` | Page background, text on dark |
| cream-2 | `#FBF5EA` | Cards, secondary buttons, input bg |
| saffron | `#E8871E` | **Sparingly**: primary CTAs, café announcement band, Indus callout, cart badge |
| teal | `#6F9A97` | Cold brew only (café menu card) |
| muted | `#6B5446` | Secondary text on cream (≥4.5:1) |
| cream-muted | `#E6D8C3` | Secondary text on espresso |
| rule-dark | `#6B4A38` | Hairline dividers on espresso |
| rule-light | `#D9C8B0` / `#C9B498` | Mobile menu dividers / menu dotted leaders |
| hover-link | `#A85A0C` | `a:hover` on cream |
| error | `#A33A12` | Form error text |

### Typography
- **Display:** Archivo Black 400 (Google Fonts). Headings, buttons, wordmark, prices. Big headings are uppercase with letter-spacing −0.01 to −0.04em and line-height 0.8–1.
- **Body:** Source Sans 3 400/600/700. Body 17–19px, line-height 1.45–1.55.
- **Eyebrow labels:** Source Sans 3 700, 13px, uppercase, letter-spacing .12em, colour muted.
- **Fluid scale (clamp):**
  - Hero H1: `clamp(40px, 6.4vw, 80px)`
  - Indus: `clamp(72px, 13vw, 168px)`
  - $10,035: `clamp(72px, 15vw, 200px)`
  - "Spotted.": `clamp(80px, 17vw, 240px)`
  - Section H2: `clamp(36px, 5vw, 60px)`
  - Card H2: 34px
  - Minimum text size: 13px (eyebrows); legal text is 14px.

### Shape
- **Radii:**
  - Pills and buttons: 999px
  - Cards: 24px
  - Big panels: 28–32px
  - Photos: 18–28px
- **Borders:** 3px espresso on cards and panels, 2.5px on pills and icon buttons, 2px on list rules.
- **Shadows:** flat offset only.
  - Primary buttons: `4px 4px 0 #3A2218`, or `4px 4px 0 #F5ECDC` on dark backgrounds.
  - Hero plate and newsletter card: `8px 8px 0 #3A2218`.
  - Spotted zoom circles: `6px 6px 0 #E8871E`.
- **Rotations:** hero plate −1.2°, Signature roast badge +10°, story photo +1°, "Now open" chip −2°, zoom circles −6° / +5°.

### Spacing
- Container: max-width 1280px (Spotted section is 1440px), side padding `clamp(16px, 4vw, 40px)`.
- Section vertical padding: `clamp(56px, 9vw, 112px)`.
- Gaps: 10–12 (pill groups), 16–20 (cards), 24–48 (columns), `clamp(32px, 6vw, 80px)` (two-column splits).
- Touch targets: at least 48px; primary buttons are 52–56px tall.

### Buttons
- **Primary:** saffron bg, espresso text, 3px espresso border, 4px offset shadow, Archivo Black 17px, padding 0 26px, min-height 52px.
- **Secondary:** cream-2 bg, same border, no shadow.
- **Dark:** espresso bg, cream text.
- **On dark backgrounds:** outline style, with a cream border and cream text.
- All buttons: `white-space: nowrap`, and they must not shrink (`flex: none`).
- **Suggested hover:** translate(−2px, −2px) and grow the shadow to 6px. **Active:** translate(2px, 2px) with no shadow.

## Global: Header / Nav (both pages)
- Sticky, cream bg, 3px espresso bottom border.
- **Left:** logo (52px circle, 2.5px espresso border, white bg), then the "Singh Beans" wordmark in Archivo Black 20px. It links home.
- **Nav, in order, exactly:** Café, Shop, Coffee Cart, Wholesale, Our Story. Source Sans 700 16px, gap 28px. The current page is underlined in saffron, 3px.
- **Right:** cart icon button (48px circle, cream-2, 2.5px border) with a saffron count badge (20px, top-right).
- **Below 900px:** the nav links are replaced by a hamburger (48px espresso circle). It toggles a full-width dropdown with the links in Archivo Black 26px, each 12px-padded with a divider. Tapping an anchor link closes it.
- Nothing else goes in the header. No promo bar.

## Global: Footer (both pages)
- Espresso background.
- **Left:** the logo (96px circle), then round 48px outline icon buttons for Instagram and Facebook. Icons only; use a real icon set (the mock draws them with CSS).
- **Help links**, in a two-column grid:
  - FAQ → /faq
  - Shipping policy → /shipping-policy
  - Contact us → /contact-us
  - Brew guides → /brew-guides
- **Outline pill:** "In the UK? Shop our UK site" → https://singhbeans.co.uk/
- **Legal row** (14px, above a 1.5px divider): "© 2026 Singh Beans Ltd." · Privacy → /privacy-policy · Terms of service → /terms-of-services
- **Social:** instagram.com/singhbeans, facebook.com/singhbeans

## Screen 1: Homepage (`Homepage.dc.html`)
Sections in order:

1. **Hero** (the "Full-bleed photo" variant is the default)
   - Full-width `assets/mug.webp`, height `clamp(560px, 86vh, 820px)`, object-position 32% 40%.
   - A cream "sticker plate" is anchored bottom-right: max-width 640px, 3px border, radius 28px, 8px shadow, rotated −1.2°.
   - H1 (uppercase): "Coffee is the only thing we take seriously."
   - CTAs:
     - "Visit the Café" (primary) → café page
     - "Shop Beans" (secondary) → shop
   - An alternative "Split colour block" variant: espresso left panel with the headline, photo right.
2. **Café announcement band**
   - Saffron background, full width, borders top and bottom.
   - "NOW OPEN IN SURREY" (Archivo Black `clamp(28px, 4.4vw, 44px)`), with the sub-line "Our first café. Same beans, now with a counter."
   - An `<address>` block: street address **TBC**, "Surrey, BC", "Mon–Fri 7am–5pm · Sat–Sun 8am–4pm" (**hours TBC**).
   - "Get Directions" button, dark style.
   - The city (Surrey or Vancouver) is still undecided and is a single variable.
3. **Three-path chooser**
   - Three equal cards: grid `auto-fit, minmax(280px, 1fr)`, gap 20px.
   - Each card: cream-2 bg, 3px border, radius 24px, min-height 260px. It holds an eyebrow, an H2, one line of copy, and one dark CTA pinned to the bottom.
   - **Shop Beans:** "For home" / "Small-batch roasts, bagged the week they ship." / "Shop all coffee"
   - **Book the Cart:** "For events & weddings" / "Our mobile espresso bar, parked wherever you're celebrating." / "Check a date" → /event-vendor
   - **Wholesale:** "For cafés & offices" / "Fresh-roasted beans and training for your team." / "Become a partner" → /wholesale
4. **Featured roast: Indus**
   - Espresso background, two columns (collapsing at 400px).
   - **Left:** `assets/indus.webp` inside a saffron frame (aspect 4/5, radius 32px, padding 16–32px), with the image radius 20px and a 3px border. A 110px cream circle badge reading "SIGNATURE ROAST" overlaps the top-right, rotated 10°.
   - **Right:**
     - "INDUS" in saffron at display scale
     - Copy: "Medium-dark, washed, from India. Warm, spiced and a little bit loud — like every family dinner we've ever had."
     - Three outline pills (2.5px cream border): Masala chai spice · Dried dates · White pepper
     - "Order Indus" primary button, with a cream border and cream shadow
     - Meta line: "340 g · 1 lb · 5 lb bags"
5. **Our story**
   - `assets/founders-counter.webp`: aspect 4/3, 3px border, radius 28px, rotated 1°.
   - Eyebrow "Our story", then H2 "Three of us. One roaster. Zero chill about coffee."
   - One paragraph (see file), then the link "Read the full story" → /our-story.
6. **Giving back**
   - Cream-2 background, borders top and bottom.
   - Headline row: "$10,035" at display scale, beside "raised as of December 2025. Every bag funds a local cause — started in memory of a friend we lost to Muscular Dystrophy in 2018."
   - Below: `assets/event-tent.webp` (4/3), and next to it a list of six charity **wordmarks* in Archivo Black, 18–24px, colour muted, each separated by a 2px rule and linking out:
     - Muscular Dystrophy Canada (muscle.ca)
     - Dan's Legacy (danslegacy.com)
     - BC Children's Hospital (bcchildrens.ca)
     - Community Arts Council of Vancouver (cacv.ca)
     - Covenant House (covenanthousebc.org)
     - Steer Friends (steerfriends.org)
7. **Spotted**, the brand's most distinctive content, so give it room.
   - Espresso background.
   - Huge "SPOTTED." with an intro: "Our stickers get around — street boxes, lampposts, the odd city on another continent. Spot one? Tag @singhbeans and it goes up on this wall."
   - An outline button, "Tag us on Instagram".
   - Grid `auto-fit, minmax(420px, 1fr)` of sticker photos, aspect 3/2, radius 24px.
   - Each photo has a **160px circular zoom** of the Singh Beans sticker bottom-right: a background-image crop of the same photo, 5px cream border, 6px saffron offset shadow, slight rotation. The mock hard-codes the crop coordinates per photo. Production should use a CMS field for the zoom focal point, or a pre-cropped image.
   - Built to grow: a masonry wall once more photos exist, possibly pulled from Instagram.
8. **Stockists + Newsletter** (two columns)
   - **Stockists:** "Also on shelves at", a compact list. Each row has a map-pin (an 18px teardrop in espresso), the name, and the address in muted text.
     - Krave Health Club — 3211 152 St, Surrey
     - Singh Styles — 6638 152A St #108, Surrey
     - The Whole Bowl — 15345 56 Ave #102, Surrey
     - Provisions Market + Gifts — 20581 Fraser Hwy, Langley
   - **Newsletter card:** cream-2, 3px border, radius 28px, 8px shadow.
     - "New roasts, first dibs." / "One email when something new comes out of the roaster. That's it."
     - One email input (pill, 56px, with a visually hidden label) and a "Sign me up" primary button.
9. **Footer**

## Screen 2: Café landing page (`Cafe.dc.html`)
Structured for local SEO. The business name, address, phone and hours **must be real text**, not images.

1. **Hero** (two columns, collapsing at 440px)
   - **Left:** `assets/founders-counter.webp`, min-height `clamp(340px, 64vh, 720px)`. Swap in café interior or exterior photos when they exist.
   - **Right:**
     - A saffron "NOW OPEN" chip, rotated −2°
     - H1 "SINGH BEANS CAFÉ, SURREY"
     - `<address>`: street **TBC**, then Surrey, BC
     - Phone: `tel:` link, **number TBC** (the mock uses 604-555-0142)
     - Hours as a `<dl>`: Mon–Fri 7am–5pm, Sat–Sun 8am–4pm
     - Buttons: "Get Directions" (primary, jumps to the map) and "Call the café" (secondary)
2. **Menu preview**
   - H2 "ON THE MENU", with the line "A taste of what's behind the counter. Oat, soy and almond milk at no extra charge." (**confirm with the client**)
   - **Signature panel:** saffron, 3px border, radius 28px.
     - "Signature" chip, then "Indus Chai-Spiced Latte"
     - Description (see file), $6.50
     - Photo alongside
   - Then three cards:
     - Espresso (cream-2): Espresso, Cortado, Flat white, Latte, Americano
     - Cold Brew (**teal**): Cold brew black, Cold brew + milk, Iced Indus latte
     - Pastries (cream-2): Butter croissant, Cardamom bun, Banana bread
   - Rows use a dashed 1.5px leader and a bold price.
   - **All prices and items are placeholders.**
3. **Photo strip:** a horizontal scroll-snap row of 4 photos (`clamp(260px, 34vw, 440px)` square-ish, radius 20px).
4. **Find us** (`#map`)
   - Address block, with the parking note "Street parking out front. Bike rack by the door." (**TBC**).
   - An "Open in Maps" primary button.
   - A map panel (3px border, radius 28px, height `clamp(320px, 44vw, 480px)`). **Embed Google Maps here** once the address is confirmed.
5. **Cross-link band**
   - Espresso background: "LIKED IT? TAKE IT HOME." with "Every bean we pour at the counter is for sale online — Indus included."
   - "Order beans to take home" → shop / Indus product.
6. **Footer**

### Local SEO requirements
- `<title>`: "Singh Beans Café — Surrey, BC | Coffee, Indus Chai Latte & Pastries". Also add a meta description.
- JSON-LD `CafeOrCoffeeShop` in the head, with the name, address, telephone and openingHoursSpecification. A template is in the `Cafe.dc.html` helmet. Fill in the real data.
- Include the NAP (name, address, phone) in the page body. It should match the Google Business Profile exactly.

## Interactions & Behavior
- **Mobile nav:** switch at the 900px breakpoint. The hamburger toggles `menuOpen`.
- **Cart:** the badge shows the item count. In the mock, "Order Indus" increments it and the label changes to "Added — order another". In production, wire it to the real cart or add-to-cart.
- **Newsletter:**
  - Validate on submit with `/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/`.
  - Invalid: show "That email doesn't look quite right." in error colour, bold, with `role="alert"`.
  - Valid: replace the form with an espresso panel reading "You're on the list. Next roast, you'll hear first." (`role="status"`).
  - Hook it up to the client's ESP; the current Squarespace form has no storage.
- **Anchors:** Shop → #shop, Coffee Cart → #cart-booking, Wholesale → #wholesale, Our Story → #story. All have scroll-margin-top 80px because of the sticky header. In production, point these to real pages.
- **Responsive:** built entirely on `grid auto-fit minmax(min(100%, Npx), 1fr)` plus `flex-wrap`, with fluid `clamp()` type. There are no fixed widths on text containers. Test at 360, 768, 1024 and 1440.
- **Motion:** none specified. Keep it minimal, e.g. button press or hover translations at 120ms ease-out, and respect `prefers-reduced-motion`.

## State
- `menuOpen` (bool)
- `cartCount` (int, from the cart API)
- `newsletter.email` (string)
- `newsletter.status` (`idle` | `error` | `done`)
- `cafeCity` (config value: "Surrey" | "Vancouver", used in the band, H1, address and title)

## Assets (`assets/`)
| File | Content | Used in |
|---|---|---|
| `logo.jpg` | Official turbaned-man logo (line art in a circle, white background). **Do not redraw.** Ask the client for an SVG. | Nav, footer |
| `mug.webp` | Man drinking from a Singh Beans mug, logo beanie | Homepage hero, café strip |
| `founders-counter.webp` | Two founders behind the wooden coffee counter | Our story, café hero |
| `indus.webp` | Indus bag held in hands (portrait) | Indus feature, café signature panel |
| `event-tent.webp` | Team volunteering at a charity event | Giving back, café strip |
| `spotted-red.webp` | Singh Beans sticker on a red street box | Spotted, café strip |
| `spotted-green.webp` | Singh Beans sticker on a green box overseas | Spotted, café strip |

All photos were supplied by the client. Before launch, request higher-resolution originals, café interior and exterior photos, and more sticker-spotting photos.

## Open items (TBC)
- Café city, street address, phone, hours and parking note
- Menu items and prices
- Google Maps embed
- Logo as SVG
- Newsletter ESP
- Destination URLs for the shop, product, event booking, wholesale form and full story (the current Squarespace paths are used in the mock)

## Files
- `Homepage.dc.html`: homepage design reference
- `Cafe.dc.html`: café landing page design reference
- `assets/`: images
- `support.js`: runtime that lets the reference files open in a browser only; not part of the build
